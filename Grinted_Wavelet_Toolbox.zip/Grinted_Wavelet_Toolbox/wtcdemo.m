%% Demo of the cross wavelet and wavelet coherence toolbox 

clear all;
%% Load the data
% First we load the two time series into the matrices d1 and d2.

filtered_data  = readtable("D:\Second year\First semester\Statistics\Stat_coding\Storms\cycle.csv");

seriesname = {'GTEC' 'Dst' 'Kp'};

d3 = filtered_data.Kp;
d2 = filtered_data.Dst;
d1 = filtered_data.GTEC;
d1= fillmissing(d1, 'spline');

%% Data for differents storms

filtered_data  = readtable("D:\Second year\First semester\Statistics\Stat_coding\Storms\st17.csv");

seriesname = {'GTEC' 'Dst' 'Kp' 'Bz'};
k4 = filtered_data.Bz;
k3 = filtered_data.Kp;
k2 = filtered_data.Dst;
k1 = filtered_data.GTEC;
%% ------------------The enhanced time series---------------------%%

filtered_data  = readtable("D:\Second year\First semester\Statistics\Stat_coding\Storms\Orage24.csv");

seriesname = {'GTEC' 'Dst' 'Kp'};

z3 = filtered_data.Kp;
z2 = filtered_data.Dst;
z1 = filtered_data.GTEC;
z11 = filtered_data.gtec;

%% Continuous wavelet transform (CWT)
% The CWT expands the time series into time
% frequency space.

% figure('color',[1 1 1])
% tlim=[min(d1(1,1),d2(1,1)) max(d1(end,1),d2(end,1))];
% % xticks_years = 2010:2024;
% % xticks_days = (xticks_years - 2010) * 365.25;
%  subplot(3,1,1);
%  % [wave,period,scale,coi,sig95]=wt(d1);
%   rect = [ 0.12  0.55  0.7  0.28 ];axes( 'position' , rect); 
% wt(d1);
% title(seriesname{1});
% set(gca,'FontWeight','bold','FontSize',15);
% set(gca,'XLim')
% xticks_years = 2010:2024;
% xticks_days = (xticks_years - 2010) * 365.25;
% set(gca, 'XTick', xticks_days);
% set(gca, 'XTickLabel', string(xticks_years));
% ylabel('Period (days)')
% xlabel([]);
% c = colorbar('Position', [0.12, 0.35, 0.7, 0.04], 'Orientation', 'horizontal');
%  colormap('jet');
% % c=colorbar();
% 
% 
% rect = [ 0.82  0.55  0.1  0.28 ];
% axes( 'position' , rect );
% plot(pw./var(d1),period)
% ylim([1 512]);
% xticks([0 10 30 50]);
% yticklabels([]);
% xlabel('Mean');
% set(gca,'FontWeight','bold','FontSize',15);
% set(gca, 'xdir','normal','FontWeight','bold','FontSize',15);
% set(gca, 'ydir','reverse','FontWeight','bold','FontSize',15);

filtered_data1  = readtable("D:\Second year\First semester\Statistics\Stat_coding\Storms\puissance.csv");                                         %filtered_data.days';
GTECq =  filtered_data1.p1;
kpInd =  filtered_data1.p2;
DstInd =  filtered_data1.p3;
T =  filtered_data1.t;

subplot(3,2,1);
wt(d1);
fontsize(gca, 15,'points') 
set(gca,'FontWeight','bold','FontSize',15);
% set(gca,'XLim')
% xticks_years = 2010:2024;
% xticks_days = (xticks_years - 2010) * 365.25;
% set(gca, 'XTick', xticks_days);
% set(gca, 'XTickLabel', string(xticks_years));
title('a) Wavelet scalogram: GTEC','FontSize',15);
xticklabels([])
ylabel('Period (days)')
colormap('jet');
c=colorbar();

subplot(3,2,2)

plot(T, GTECq,LineStyle="-",LineWidth=2,Color='b');
axis tight 
ylabel('Norm power','FontSize',15);
set(gca,'FontWeight','bold','FontSize',15);
%title('Geomagnetic storm of 03-08/04/2010','FontSize',15);
title('b) Wavelet normalized power spectrum: GTEC','FontSize',15);
xticklabels([])
hold off;
grid on

subplot(3,2,3);
wt(d2);
fontsize(gca, 15,'points') 
set(gca,'FontWeight','bold','FontSize',15);
% set(gca,'XLim')
% xticks_years = 2010:2024;
% xticks_days = (xticks_years - 2010) * 365.25;
% set(gca, 'XTick', xticks_days);
% set(gca, 'XTickLabel', string(xticks_years));
title('c) Wavelet scalogram: Kp','FontSize',15);
xticklabels([])
ylabel('Period (days)')
colormap('jet');
c=colorbar();

subplot(3,2,4)

plot(T, kpInd,LineStyle="-",LineWidth=2,Color='b');
axis tight 
ylabel('Norm power','FontSize',15);
set(gca,'FontWeight','bold','FontSize',15);
%title('Geomagnetic storm of 03-08/04/2010','FontSize',15);
title('d) Wavelet normalized power spectrum: Kp','FontSize',15);
xticklabels([])
hold off;
grid on


subplot(3,2,5);
wt(d3);
fontsize(gca, 15,'points') 
set(gca,'FontWeight','bold','FontSize',15);
set(gca,'XLim')
xticks_years = 2010:2024;
xticks_days = (xticks_years - 2010) * 365.25;
set(gca, 'XTick', xticks_days);
set(gca, 'XTickLabel', string(xticks_years));
title('e) Wavelet scalogram: Dst','FontSize',15);
ylabel('Period (days)')
xlabel('Time (years)')
colormap('jet');
c=colorbar();

subplot(3,2,6)

plot(T, DstInd,LineStyle="-",LineWidth=2,Color='b');
axis tight 
ylabel('Norm power','FontSize',15);
set(gca,'FontWeight','bold','FontSize',15);
title('f) Wavelet normalized power spectrum: Dst','FontSize',15);
xlabel('Period (days)')
hold off;
grid on


% [wave,period,scale,coi,sig95]=wt(d1);
% 
% power = (abs(wave)).^2 ;
% pw = mean(power,2);



%% Cross wavelet transform (XWT)
% The XWT finds regions in time frequency space where
% the time series show high common power.

figure('color',[1 1 1])
xwt(z1,z2)
% ---------------------for the year stick-----------------
 set(gca,'FontWeight','bold','FontSize',15);
% set(gca,'XLim')
% xticks_years = 2010:2024;
% xticks_days = (xticks_years - 2010) * 365.25;
% set(gca, 'XTick', xticks_days);
% set(gca, 'XTickLabel', string(xticks_years));
% ---------------------day stick--------------------------
startDate = datetime(2017,5,25);   % adjust year as needed
endDate = datetime(2017,5,30);
timeVec = linspace(startDate, endDate, length(z1));
% xticks_days = linspace(datetime('May 25, 2017 00:00:00'),datetime('May 30, 2017 23:00:00'),length(k1));
% set(gca, 'XTick');
xticks = linspace(1, length(z1), 6);  
xticklabels({'May 25', 'May 26', 'May 27', 'May 28', 'May 29', 'May 30'});
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)


colormap('jet');
c=colorbar();
fontsize(gca, 15,'points') 
title(['XWT: ' seriesname{1} '-' seriesname{2} ] )

%% Wavelet coherence (WTC)
% The WTC finds regions in time frequency space where the two
% time series co-vary (but does not necessarily have high power).



figure('color',[1 1 1])
wtc(z11,z3);   %,'mcc',0);


set(gca,'FontWeight','bold','FontSize',15);
% set(gca,'XLim')
% xticks_years = 2010:2024;
 % xticks_days = (xticks_years - 2010) * 365.25;
% set(gca, 'XTick', xticks_days);
% set(gca, 'XTickLabel', string(xticks_years));

startDate = datetime(2024,5,08);   % adjust year as needed
endDate = datetime(2024,5,13);
% timeVec = linspace(startDate, endDate, length(k1));
% xticks_days = linspace(datetime('May 25, 2017 00:00:00'),datetime('May 30, 2017 23:00:00'),length(k1));
% set(gca, 'XTick');
xticks = linspace(1, length(z1), 6);  
xticklabels({'May 08', 'May 09', 'May 10', 'May 11', 'May 12', 'May 13'});
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
colormap('jet');
c=colorbar();
fontsize(gca, 15,'points') 

xlabel('Time (days)')
ylabel('Period (hours)')
title(['d) Wavelet coherence: ' seriesname{1} '-' seriesname{3} ] )
%% --------------calculation of the average phase around a certain period---------------%%

t=(1:1:144)';
X=   z11;                
Y=   z3;               
[Wxy,period,scale,coi,sig95]=xwt([t X], [t Y]);
[mn,rowix]=min(abs(period-27.7879)); %row with period closest to 11.

incoi=(period(:)*(1./coi)>1);
issig=(sig95>=1);
angles=angle(Wxy(rowix,issig(rowix,:)&~incoi(rowix,:)));
[meantheta,anglestrength,sigma]=anglemean(angles);

%-------------------coversion in degrees-------------------%

D1 = rad2deg(meantheta);
D2 = rad2deg(sigma);

%% 

%% 
filtered_data  = readtable("D:\Second year\First semester\Statistics\Stat_coding\Storms\STGTEC.csv");
GTEC =  filtered_data.S24;
data_reshaped = reshape(GTEC, 4, []);
mean_vector = mean(data_reshaped, 1)';




